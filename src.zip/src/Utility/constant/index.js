export const API_BASE_URL = 'https://api.escuelajs.co/api/v1';
